# The views.py file is used to handle the logic for what happens when a user requests a specific page or performs an action on a web application.
# Handling Requests and Responses
# Interfacing with Models
# Rendering Templates
# Handling Business Logic

# Home
# favviewpage
# remove_fav
# cart_page
# remove_cart
# fav_page
# add_to_cart
# logout_page
# login_page
# register
# collections
# collectionsview
# product_details

import json
from django.shortcuts import render
from . models import *
from django.http import HttpResponse
from django.contrib import messages
from django.shortcuts import render,redirect
from django.shortcuts import render, get_object_or_404
from shop.form import CustomUserForm
from django.contrib.auth import authenticate,login,logout
from django.http import JsonResponse


def home(request):       #Its filter the trending product and display that in home page
  products=Product.objects.filter(Trending=1)
  return render(request,"shop/index.html",{"products":products})

def favviewpage(request):       #Its checks user are authenticated then filter the user favorite items and display it on fav.html
  if request.user.is_authenticated:
    fav=Favourite.objects.filter(user=request.user)
    return render(request,"shop/fav.html",{"fav":fav})
  else:
    return redirect("/")
  
def remove_fav(request,fid):        #Its gets a (fid) it means favourite items and that item are deleted and redirect to favviewpage 
  item=Favourite.objects.get(id=fid)
  item.delete()
  return redirect("/favviewpage")


def cart_page(request):        #Its checks user are authenticated and add the items to cart and display it on cart.html
  if request.user.is_authenticated:
    cart=Cart.objects.filter(user=request.user)
    return render(request,"shop/cart.html",{"cart":cart})
  else:
    return redirect("/")
  
def remove_cart(request,cid):          #Its gets a (cid) it means cart item and that item are deleted and redirect to cart page
  cartitem=Cart.objects.get(id=cid)
  cartitem.delete()
  return redirect("/cart")



# The function fav_page check the response are coming from correct website by CSRFToken  else: its gives a meassage like "Invalid Access"
# And its check user are authenticated then get product id and product status else: its gives a meassage like 'Login to Add Favourite'
# When the product_status is satisfied its gives a meassage like 'Product already added to favourite' else: its gives a meassage like 'Product added to favorite'
def fav_page(request):      
   if request.headers.get('x-requested-with')=='XMLHttpRequest':
    if request.user.is_authenticated:
      data=json.load(request)
      product_id=data['pid']
      product_status=Product.objects.get(id=product_id)
      if product_status:
         if Favourite.objects.filter(user=request.user.id,product_id=product_id):
          return JsonResponse({'status':'Product already added to favourite'}, status =200)
         else:
          Favourite.objects.create(user=request.user,product_id=product_id)
          return JsonResponse({'status':'Product added to favorite'}, status=200)
    else:
       return JsonResponse({'status':'Login to Add Favourite'}, status=200)
   else:
      return JsonResponse({'status':"Invalid Access"}, status=200)



# The function add_to_cart check the response are coming from correct website by CSRFToken  else: its gives a meassage like "Invalid Access"
# And its check user are authenticated then get product id and product status else: its gives a meassage like 'Login to Add cart' its get a product id and quantity.
# Then its checks the product are already in cart if it is satisfied its gives a message like 'Product already in cart'
# then its checks the product status it means its checks the product are available then its gives a message like 'Product added to cart'
# else: its gives a message like 'Product stock not available'
def add_to_cart(request):
   if request.headers.get('x-requested-with')=='XMLHttpRequest':
    if request.user.is_authenticated:
      data=json.load(request)
      product_qty=data['product_qty']
      product_id=data['pid']
      #print(request.user.id)
      product_status=Product.objects.get(id=product_id)
      if product_status:
         if Cart.objects.filter(user=request.user.id,product_id=product_id):
             return JsonResponse({'status':'Product already in cart'}, status =200)
         else:
            if product_status.quantity>=product_qty:
               Cart.objects.create(user=request.user,product_id=product_id,product_qty=product_qty)
               return JsonResponse({'status':'Product added to cart'}, status =200)
            else:
                return JsonResponse({'status':'Product stock not available'}, status =200)
    else:
       return JsonResponse({'status':'Login to Add Cart'}, status=200)
   else:
      return JsonResponse({'status':"Invalid Access"}, status=200)

def logout_page(request):    # Its check the user are already login then its logout the account and its gives a message like "Logged out Successfully" 
  if request.user.is_authenticated:
    logout(request)
    messages.success(request,"Logged out Successfully")
  return redirect("/")



# Its checks the user are already login  then it get a name and password by POST method and checks the user are already login by the database
# it is not satisfied its gives a message like "Invalid User Name or Password"
# then it checks the user are already active or not if it is satisfied then it login the user

def login_page(request):    
   if request.user.is_authenticated:
       return redirect("/")
   else:
     if request.method == 'POST':
       name=request.POST.get('username')
       pwd=request.POST.get('password')
       user=authenticate(register,username=name,password=pwd)
       if user is not None:
         login(request,user)
         messages.success(request,"Logged in Successfully")
         return redirect("/")
       else:
         messages.error(request,"Invalid User Name or Password")
         return redirect("/login")
     return render(request,"shop/login.html")


# Its checks the user are already login then it get a name and password by POST method and checks
# and its gives a message like "Registration success you can login now...!"

def register(request):
  form=CustomUserForm()
  if request.method == 'POST':
    form = CustomUserForm(request.POST)
    if form.is_valid():
      form.save()
      messages.success(request,"Registration success you can login now...!")
      return redirect('/login')
  return render(request,"shop/register.html",{'form':form})


def collections(request):         # Its used to display all categories on collections.html
  catagory=Catagory.objects.filter(status=0)
  return render(request,"shop/collections.html",{"catagory":catagory})


def collectionsview(request,name):      # This function is used to display a list of products belonging to a specific category.
  if(Catagory.objects.filter(name=name,status=0)):
      products=Product.objects.filter(category__name=name)
      return render(request,"shop/products/index.html",{"products":products,"category_name":name})
  else:
    messages.warning(request,"No Such Catagory Found")
    return redirect('collections')
    

def product_details(request,cname,pname):      # Function is used to display detailed information about a specific product
  if(Catagory.objects.filter(name=cname,status=0)):
    if(Product.objects.filter(name=pname,status=0)):
        products=Product.objects.filter(name=pname,status=0).first()
        return render(request,"shop/products/product_detail.html",{"products":products})
    else:
        messages.error(request,"No Such Product Found")
        return redirect('collections')
  else:
      messages.error(request,"No Such Catagory Found")
      return redirect('collections')
