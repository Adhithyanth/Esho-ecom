''' the admin.py file is used to configure the Django admin interface,
 which is a built-in feature that provides a powerful and user-friendly interface for managing data models in your application.
 The Django admin site allows you to perform CRUD (Create, Read, Update, Delete) operations on your models, manage users,
 and administer your application without needing to write custom views or templates for these tasks. '''
from django.contrib import admin
from .models import *

'''
class CategoryAdmin(admin.ModelAdmin):
    list_display=('name','image','description')
    admin.site.register(Catagory,CategoryAdmin)
'''
admin.site.register(Catagory)
admin.site.register(Product)
admin.site.register(Cart)
admin.site.register(Favourite)